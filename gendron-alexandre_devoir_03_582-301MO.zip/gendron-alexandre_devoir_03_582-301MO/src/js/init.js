const config = {
    type: Phaser.AUTO,
    parent: "canvas-wrapper",
    width: 800,
    height: 600,
    scene: [Accueil, Jeu, CommentJouer, Credits, Victoire, Defaite],
    transparent: true,
    pixelArt: true
};
const game = new Phaser.Game(config);