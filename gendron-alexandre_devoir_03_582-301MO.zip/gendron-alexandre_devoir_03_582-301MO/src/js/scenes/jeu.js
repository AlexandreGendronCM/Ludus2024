class Jeu extends Phaser.Scene {


    constructor() {
        super({ key: "jeu" });
    }


    preload() {

        this.load.image("bg", "assets/img/background_glacial_mountains.png");
        this.load.image("logo", "assets/img/Sprite-testLogo.png");
        this.load.image("btnVictoire", "assets/img/btnVictoire.png");
        this.load.image("btnDefaite", "assets/img/btnDefaite.png");



    }

    create() {

        let unSurCentConfigW = (config.width / 100);
        let unSurCentConfigH = (config.height / 100);

        let bg = this.add.image(0, 0, "bg").setOrigin(0, 0);
        let logo = this.add.image(config.width / 2, 0, "logo").setOrigin(0.5, 0);
        let btnVictoire = this.add.image(unSurCentConfigW * 10, unSurCentConfigH * 75, "btnVictoire").setOrigin(0, 0);
        let btnDefaite = this.add.image((config.width) - unSurCentConfigW * 10, unSurCentConfigH * 75, "btnDefaite").setOrigin(1, 0);

        let scaleX = config.width / bg.width;
        let scaleY = config.height / bg.height;
        let scale = Math.max(scaleX, scaleY);

        bg.setScale(scale);
        logo.setScale(scale / 1.5);
        btnVictoire.setScale(scale / 10);
        btnDefaite.setScale(scale / 10);


        logo.setInteractive();
        logo.on("pointerdown", function () {

            this.scene.start("accueil")

        }, this);

        btnVictoire.setInteractive();
        btnVictoire.on("pointerdown", function () {

            this.scene.start("victoire")

        }, this);


        btnDefaite.setInteractive();
        btnDefaite.on("pointerdown", function () {

            this.scene.start("defaite")

        }, this);




    }

    update() {

    }
}
