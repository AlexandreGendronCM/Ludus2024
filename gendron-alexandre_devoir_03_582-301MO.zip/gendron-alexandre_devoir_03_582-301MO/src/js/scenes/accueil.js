class Accueil extends Phaser.Scene {


    constructor() {
        super({ key: "accueil" });
    }


    preload() {



        this.load.image("bg-intro", "assets/img/background_glacial_mountains.png");
        this.load.image("logo", "assets/img/Sprite-testLogo.png");
        this.load.image("titleCard", "assets/img/TitleCard.png");
        this.load.image("btnCommencer", "assets/img/btnCommencer.png");
        this.load.image("btnCommentJouer", "assets/img/btnCommentJouer.png");
        this.load.image("btnCredits", "assets/img/btnCredits.png");




    }

    create() {

        let unSurCentConfigW = (config.width / 100);
        let unSurCentConfigH = (config.height / 100);

        let bgIntro = this.add.image(0, 0, "bg-intro").setOrigin(0, 0);
        let logoIntro = this.add.image(config.width / 2, 0, "logo").setOrigin(0.5, 0);
        let titleCard = this.add.image(config.width / 2, config.height / 6, "titleCard").setOrigin(0.5, 0);
        let btnCommencer = this.add.image(config.width / 2, config.height / 3, "btnCommencer").setOrigin(0.5, 0);
        let btnCommentJouer = this.add.image(unSurCentConfigW * 10, unSurCentConfigH * 75, "btnCommentJouer").setOrigin(0, 0);
        let btnCredits = this.add.image((config.width) - unSurCentConfigW * 10, unSurCentConfigH * 75, "btnCredits").setOrigin(1, 0);







        let scaleX = config.width / bgIntro.width;
        let scaleY = config.height / bgIntro.height;
        let scale = Math.max(scaleX, scaleY);

        bgIntro.setScale(scale);
        titleCard.setScale(scale / 4.5);
        btnCommencer.setScale(scale / 8.5);
        btnCommentJouer.setScale(scale / 10);
        btnCredits.setScale(scale / 10);
        logoIntro.setScale(scale / 1.5);


        btnCommencer.setInteractive();
        btnCommencer.on("pointerdown", function () {

            this.scene.start("jeu")

        }, this);


        btnCommentJouer.setInteractive();
        btnCommentJouer.on("pointerdown", function () {

            this.scene.start("commentjouer")

        }, this);

        btnCredits.setInteractive();
        btnCredits.on("pointerdown", function () {

            this.scene.start("credits")

        }, this);



    }

    update() {

    }
}


