class Defaite extends Phaser.Scene {

    constructor() {
        super({ key: "defaite" });
    }



    preload() {



        this.load.image("bg", "assets/img/background_glacial_mountains.png");
        this.load.image("logo", "assets/img/Sprite-testLogo.png");
        this.load.image("btnCommencer", "assets/img/btnCommencer.png");




    }

    create() {

        let unSurCentConfigW = (config.width / 100);
        let unSurCentConfigH = (config.height / 100);

        let bg = this.add.image(0, 0, "bg").setOrigin(0, 0);
        let logo = this.add.image(config.width / 2, 0, "logo").setOrigin(0.5, 0);
        let btnCommencer = this.add.image(config.width / 2, config.height / 3, "btnCommencer").setOrigin(0.5, 0);

        let scaleX = config.width / bg.width;
        let scaleY = config.height / bg.height;
        let scale = Math.max(scaleX, scaleY);

        bg.setScale(scale);
        logo.setScale(scale / 1.5);
        btnCommencer.setScale(scale / 8.5);


        logo.setInteractive();
        logo.on("pointerdown", function () {

            this.scene.start("accueil")

        }, this);


        btnCommencer.setInteractive();
        btnCommencer.on("pointerdown", function () {

            this.scene.start("jeu")

        }, this);

    }

    update() {

    }
}







